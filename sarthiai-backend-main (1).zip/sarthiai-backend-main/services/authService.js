'use strict';

const { timingSafeEqual } = require('crypto');
const bcrypt = require('bcryptjs');
const { User } = require('../models/User');
const { HttpError } = require('../errors/HttpError');
const { hashRefreshToken } = require('../utils/tokens');
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} = require('../utils/jwt');

const BCRYPT_COST = 12;

/**
 * @param {unknown} role
 * @returns {'user' | 'admin'}
 */
function normalizeRole(role) {
  return role === 'admin' ? 'admin' : 'user';
}

/**
 * @param {string} a
 * @param {string} b
 * @returns {boolean}
 */
function timingSafeEqualString(a, b) {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) {
    return false;
  }
  return timingSafeEqual(bufA, bufB);
}

/**
 * @param {import('mongoose').Document & {
 *   _id: import('mongoose').Types.ObjectId;
 *   email: string;
 *   role?: string;
 *   profile?: { displayName?: string; bio?: string; avatarUrl?: string };
 *   createdAt?: Date;
 *   updatedAt?: Date;
 * }} doc
 */
function toPublicUser(doc) {
  const profile = doc.profile || {};
  return {
    id: String(doc._id),
    email: doc.email,
    role: normalizeRole(doc.role),
    profile: {
      displayName: profile.displayName ?? '',
      bio: profile.bio ?? '',
      avatarUrl: profile.avatarUrl ?? '',
    },
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

/**
 * @param {string} userId
 * @returns {Promise<{ accessToken: string; refreshToken: string }>}
 */
async function issueTokensForUser(userId) {
  const user = await User.findById(userId);
  if (!user) {
    throw new HttpError(401, 'User not found');
  }
  const role = normalizeRole(user.role);
  const accessToken = signAccessToken(userId, role);
  const refreshToken = signRefreshToken(userId);
  const refreshTokenHash = hashRefreshToken(refreshToken);
  await User.findByIdAndUpdate(userId, { refreshTokenHash });
  return { accessToken, refreshToken };
}

/**
 * @param {{ displayName?: string; bio?: string; avatarUrl?: string } | undefined} profileInput
 */
function buildInitialProfile(profileInput) {
  if (!profileInput) {
    return undefined;
  }
  const { displayName, bio, avatarUrl } = profileInput;
  const profile = {};
  if (displayName !== undefined) profile.displayName = displayName;
  if (bio !== undefined) profile.bio = bio;
  if (avatarUrl !== undefined) profile.avatarUrl = avatarUrl;
  if (Object.keys(profile).length === 0) {
    return undefined;
  }
  return profile;
}

/**
 * @param {string} email
 * @param {string} password
 * @param {{ displayName?: string; bio?: string; avatarUrl?: string } | undefined} [profileInput]
 */
async function registerUser(email, password, profileInput) {
  const normalizedEmail = email.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(password, BCRYPT_COST);
  const initialProfile = buildInitialProfile(profileInput);
  try {
    const createPayload = { email: normalizedEmail, passwordHash };
    if (initialProfile !== undefined) {
      createPayload.profile = initialProfile;
    }
    const user = await User.create(createPayload);
    const tokens = await issueTokensForUser(String(user._id));
    return { user: toPublicUser(user), tokens };
  } catch (err) {
    if (err && typeof err === 'object' && 'code' in err && err.code === 11000) {
      throw new HttpError(409, 'An account with this email already exists');
    }
    throw err;
  }
}

/**
 * @param {string} email
 * @param {string} password
 */
async function loginUser(email, password) {
  const normalizedEmail = email.trim().toLowerCase();
  const user = await User.findOne({ email: normalizedEmail });
  if (!user) {
    throw new HttpError(401, 'Invalid email or password');
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    throw new HttpError(401, 'Invalid email or password');
  }
  const tokens = await issueTokensForUser(String(user._id));
  return { user: toPublicUser(user), tokens };
}

/**
 * @param {string} refreshToken
 * @returns {Promise<{ accessToken: string; refreshToken: string }>}
 */
async function refreshSession(refreshToken) {
  /** @type {import('jsonwebtoken').JwtPayload & { sub: string; typ: 'refresh' }} */
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw new HttpError(401, 'Invalid or expired refresh token');
  }
  const user = await User.findById(payload.sub);
  if (!user || user.refreshTokenHash == null) {
    throw new HttpError(401, 'Invalid or expired refresh token');
  }
  const incomingHash = hashRefreshToken(refreshToken);
  const matches = timingSafeEqualString(user.refreshTokenHash, incomingHash);
  if (!matches) {
    throw new HttpError(401, 'Invalid or expired refresh token');
  }
  return issueTokensForUser(String(user._id));
}

/** @param {string | undefined} refreshToken */
async function logoutUser(refreshToken) {
  if (!refreshToken) {
    return;
  }
  try {
    const payload = verifyRefreshToken(refreshToken);
    const incomingHash = hashRefreshToken(refreshToken);
    await User.updateOne(
      { _id: payload.sub, refreshTokenHash: incomingHash },
      { $set: { refreshTokenHash: null } },
    );
  } catch {
    /* ignore invalid token on logout */
  }
}

/**
 * @param {string} userId
 */
async function getUserById(userId) {
  const user = await User.findById(userId);
  if (!user) {
    throw new HttpError(404, 'User not found');
  }
  return toPublicUser(user);
}

module.exports = {
  registerUser,
  loginUser,
  refreshSession,
  logoutUser,
  getUserById,
  toPublicUser,
  normalizeRole,
};
