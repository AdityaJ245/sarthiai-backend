'use strict';

const { IntegrationSettings } = require('../models/IntegrationSettings');

/**
 * @returns {Promise<import('mongoose').Document>}
 */
async function getOrCreateSettings() {
  let doc = await IntegrationSettings.findOne();
  if (!doc) {
    doc = await IntegrationSettings.create({});
  }
  return doc;
}

/**
 * Safe payload for authenticated users (no secrets).
 */
async function getPublicIntegrationInfo() {
  const doc = await getOrCreateSettings();
  const d = doc.toObject();
  return {
    nutrition: {
      provider: d.nutritionProvider,
      apiConfigured: Boolean(d.nutritionApiBaseUrl && d.nutritionApiBaseUrl.length > 0),
    },
    webhooks: {
      configured: Boolean(d.externalWebhookUrl && d.externalWebhookUrl.length > 0),
    },
    updatedAt: d.updatedAt,
  };
}

/**
 * Full document for admins.
 */
async function getAdminIntegrationSettings() {
  const doc = await getOrCreateSettings();
  return doc.toObject();
}

/**
 * @param {{
 *   nutritionProvider?: string;
 *   nutritionApiBaseUrl?: string;
 *   externalWebhookUrl?: string;
 *   notes?: string;
 * }} patch
 */
async function updateAdminIntegrationSettings(patch) {
  const doc = await getOrCreateSettings();
  if (patch.nutritionProvider !== undefined) {
    doc.nutritionProvider = patch.nutritionProvider;
  }
  if (patch.nutritionApiBaseUrl !== undefined) {
    doc.nutritionApiBaseUrl = patch.nutritionApiBaseUrl;
  }
  if (patch.externalWebhookUrl !== undefined) {
    doc.externalWebhookUrl = patch.externalWebhookUrl;
  }
  if (patch.notes !== undefined) {
    doc.notes = patch.notes;
  }
  await doc.save();
  return doc.toObject();
}

module.exports = {
  getPublicIntegrationInfo,
  getAdminIntegrationSettings,
  updateAdminIntegrationSettings,
};
