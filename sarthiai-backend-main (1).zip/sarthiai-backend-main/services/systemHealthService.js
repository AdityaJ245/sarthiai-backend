'use strict';

const mongoose = require('mongoose');
const { env } = require('../config/env');

const READY = {
  0: 'disconnected',
  1: 'connected',
  2: 'connecting',
  3: 'disconnecting',
};

/**
 * @returns {object}
 */
function getProcessSnapshot() {
  const mem = process.memoryUsage();
  return {
    uptimeSeconds: process.uptime(),
    pid: process.pid,
    nodeVersion: process.version,
    memory: {
      rss: mem.rss,
      heapTotal: mem.heapTotal,
      heapUsed: mem.heapUsed,
      external: mem.external,
    },
  };
}

/**
 * @returns {object}
 */
function getDatabaseSnapshot() {
  const state = mongoose.connection.readyState;
  return {
    mongoose: {
      readyState: state,
      stateName: READY[state] ?? 'unknown',
    },
  };
}

/**
 * @returns {object}
 */
function getSystemHealth() {
  return {
    ok: true,
    environment: env.NODE_ENV,
    server: getProcessSnapshot(),
    database: getDatabaseSnapshot(),
    recordedAt: new Date().toISOString(),
  };
}

module.exports = {
  getSystemHealth,
  getProcessSnapshot,
  getDatabaseSnapshot,
};
