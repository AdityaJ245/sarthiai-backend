'use strict';

const { env } = require('../config/env');
const { HttpError } = require('../errors/HttpError');

/**
 * @typedef {{ label: string; score: number }} Prediction
 * @typedef {{
 *  recognized: { name: string; confidence: number; alternatives: Prediction[] };
 * }} FoodAiResult
 */

/**
 * Calls the Python microservice to recognize a food from an image.
 * @param {{ imageBuffer: Buffer; mimeType: string; filename: string }} input
 * @returns {Promise<FoodAiResult>}
 */
async function recognizeFoodViaMicroservice(input) {
  const { imageBuffer, mimeType, filename } = input;
  if (!Buffer.isBuffer(imageBuffer) || imageBuffer.length === 0) {
    throw new HttpError(400, 'Missing image bytes');
  }
  if (typeof mimeType !== 'string' || !mimeType.startsWith('image/')) {
    throw new HttpError(400, 'Invalid image type');
  }

  /** @type {FormData} */
  const form = new FormData();
  const blob = new Blob([imageBuffer], { type: mimeType });
  form.append('photo', blob, filename || 'photo.jpg');

  let res;
  try {
    res = await fetch(`${env.FOOD_AI_URL}/recognize`, { method: 'POST', body: form });
  } catch {
    throw new HttpError(502, 'Food AI service is unreachable');
  }

  const text = await res.text();
  /** @type {unknown} */
  let body = null;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }

  if (!res.ok) {
    const msg =
      body && typeof body === 'object' && body !== null && 'detail' in body
        ? String(/** @type {{ detail: unknown }} */ (body).detail)
        : `Food AI failed (${res.status})`;
    throw new HttpError(502, msg);
  }

  return /** @type {FoodAiResult} */ (body);
}

module.exports = { recognizeFoodViaMicroservice };

