'use strict';

const { env } = require('../config/env');
const { HttpError } = require('../errors/HttpError');

/**
 * @param {string} foodName
 * @returns {Promise<string>}
 */
async function getMacroSummaryFromGemini(foodName) {
  const key = env.GEMINI_API_KEY;
  if (!key) {
    throw new HttpError(500, 'Missing GEMINI_API_KEY in backend env');
  }

  const model = env.GEMINI_MODEL || 'gemini-1.5-flash';
  const prompt = [
    `Food item: ${foodName}`,
    '',
    'Return 2-5 short lines describing approximate nutrition/macros for a typical serving.',
    'Include calories and grams of protein, carbs, and fat.',
    'Keep it simple. No markdown, no disclaimers, no tables.',
  ].join('\n');

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    model,
  )}:generateContent`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-goog-api-key': key,
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 120,
      },
    }),
  });

  const text = await res.text();
  /** @type {unknown} */
  let body = null;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }

  if (!res.ok) {
    throw new HttpError(502, 'Gemini request failed');
  }

  const candidateText =
    body &&
    typeof body === 'object' &&
    'candidates' in body &&
    Array.isArray(/** @type {{ candidates?: unknown }} */ (body).candidates)
      ? /** @type {{ candidates: any[] }} */ (body).candidates?.[0]?.content?.parts?.[0]?.text
      : null;

  const out = typeof candidateText === 'string' ? candidateText.trim() : '';
  if (!out) {
    throw new HttpError(502, 'Gemini returned an empty response');
  }
  return out;
}

module.exports = { getMacroSummaryFromGemini };

