'use strict';

const mongoose = require('mongoose');
const { Meal } = require('../models/Meal');
const { User } = require('../models/User');
const { HttpError } = require('../errors/HttpError');
const { env } = require('../config/env');
const { escapeRegex } = require('../validation/mealQuery');

/**
 * @param {Date} d
 * @returns {Date}
 */
function utcDayStart(d) {
  const x = new Date(d);
  x.setUTCHours(0, 0, 0, 0);
  return x;
}

/**
 * @param {Date} d
 * @returns {Date}
 */
function utcDayEnd(d) {
  const x = new Date(d);
  x.setUTCHours(23, 59, 59, 999);
  return x;
}

/**
 * Monday 00:00 UTC of the ISO week containing `d`.
 * @param {Date} d
 * @returns {Date}
 */
function startOfIsoWeekUtc(d) {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = x.getUTCDay();
  const diff = day === 0 ? -6 : 1 - day;
  x.setUTCDate(x.getUTCDate() + diff);
  x.setUTCHours(0, 0, 0, 0);
  return x;
}

/**
 * @param {import('mongoose').Document | object} meal
 */
function toPublicMeal(meal) {
  const m = meal.toObject ? meal.toObject() : meal;
  return {
    id: String(m._id),
    userId: String(m.userId),
    title: m.title,
    notes: m.notes,
    eatenAt: m.eatenAt,
    nutrition: m.nutrition,
    createdAt: m.createdAt,
    updatedAt: m.updatedAt,
  };
}

/**
 * @param {import('mongoose').Document | object} meal
 */
function toPublicMealAdmin(meal) {
  const base = toPublicMeal(meal);
  const cal = meal.nutrition && typeof meal.nutrition.calories === 'number' ? meal.nutrition.calories : 0;
  return {
    ...base,
    suspicious: cal >= env.SUSPICIOUS_MEAL_CALORIES_MIN,
  };
}

/**
 * @param {{
 *   period?: 'today' | 'week' | 'month';
 *   from?: Date;
 *   to?: Date;
 * }} q
 * @returns {{ from: Date; to: Date } | null}
 */
function resolveDateRangeForList(q) {
  const now = new Date();
  if (q.from && q.to) {
    return { from: q.from, to: q.to };
  }
  if (q.from && !q.to) {
    return { from: q.from, to: now };
  }
  if (!q.from && q.to) {
    return { from: new Date(0), to: q.to };
  }
  if (q.period === 'today') {
    return { from: utcDayStart(now), to: utcDayEnd(now) };
  }
  if (q.period === 'week') {
    const s = new Date(now);
    s.setUTCDate(s.getUTCDate() - 7);
    return { from: s, to: now };
  }
  if (q.period === 'month') {
    const s = new Date(now);
    s.setUTCDate(s.getUTCDate() - 30);
    return { from: s, to: now };
  }
  return null;
}

/**
 * @param {string} userId
 * @param {object} query
 */
function buildUserMealFilter(userId, query) {
  /** @type {Record<string, unknown>} */
  const filter = { userId };
  const range = resolveDateRangeForList(query);
  if (range) {
    filter.eatenAt = { $gte: range.from, $lte: range.to };
  }
  if (query.q) {
    const escaped = escapeRegex(query.q);
    filter.$or = [
      { title: new RegExp(escaped, 'i') },
      { notes: new RegExp(escaped, 'i') },
    ];
  }
  return filter;
}

/**
 * @param {object} query
 */
function buildAdminMealFilter(query) {
  /** @type {Record<string, unknown>} */
  const filter = {};
  if (query.userId) {
    filter.userId = query.userId;
  }
  const range = resolveDateRangeForList(query);
  if (range) {
    filter.eatenAt = { $gte: range.from, $lte: range.to };
  }
  if (query.q) {
    const escaped = escapeRegex(query.q);
    filter.$or = [
      { title: new RegExp(escaped, 'i') },
      { notes: new RegExp(escaped, 'i') },
    ];
  }

  /** @type {Record<string, number>} */
  const calRange = {};
  if (query.suspiciousOnly) {
    calRange.$gte = env.SUSPICIOUS_MEAL_CALORIES_MIN;
  }
  if (query.minCalories !== undefined) {
    const prev = calRange.$gte;
    calRange.$gte =
      prev === undefined ? query.minCalories : Math.max(prev, query.minCalories);
  }
  if (query.maxCalories !== undefined) {
    calRange.$lte = query.maxCalories;
  }
  if (Object.keys(calRange).length > 0) {
    filter['nutrition.calories'] = calRange;
  }

  return filter;
}

/**
 * @param {string} sort
 */
function sortSpecFromQuery(sort) {
  if (sort === 'calories_desc') {
    return { 'nutrition.calories': -1, eatenAt: -1 };
  }
  return { eatenAt: -1 };
}

/**
 * @param {string} userId
 * @param {{ nutrition: object; title: string; notes: string; eatenAt: Date }} input
 */
async function createMeal(userId, input) {
  const meal = await Meal.create({
    userId,
    title: input.title,
    notes: input.notes,
    eatenAt: input.eatenAt,
    nutrition: input.nutrition,
  });
  return toPublicMeal(meal);
}

/**
 * @param {string} userId
 * @param {number} skip
 * @param {number} limit
 * @param {object} query
 */
async function listMealsForUser(userId, skip, limit, query) {
  const filter = buildUserMealFilter(userId, query);
  const sort = sortSpecFromQuery(query.sort || 'latest');
  const [items, total] = await Promise.all([
    Meal.find(filter).sort(sort).skip(skip).limit(limit).exec(),
    Meal.countDocuments(filter),
  ]);
  return {
    meals: items.map((m) => toPublicMeal(m)),
    total,
    skip,
    limit,
  };
}

/**
 * Current user only (use admin route to inspect any meal).
 * @param {string} mealId
 * @param {string} userId
 */
async function getMealForUser(mealId, userId) {
  const meal = await Meal.findById(mealId);
  if (!meal) {
    throw new HttpError(404, 'Meal not found');
  }
  if (String(meal.userId) !== userId) {
    throw new HttpError(403, 'You can only access your own meals');
  }
  return toPublicMeal(meal);
}

/**
 * @param {string} mealId
 */
async function getMealForAdmin(mealId) {
  const m = await Meal.findById(mealId).populate('userId', 'email role');
  if (!m) {
    throw new HttpError(404, 'Meal not found');
  }
  const base = toPublicMealAdmin(m);
  const u = m.userId;
  if (u && typeof u === 'object' && 'email' in u && '_id' in u) {
    return {
      ...base,
      user: {
        id: String(/** @type {import('mongoose').Types.ObjectId} */ (u._id)),
        email: u.email,
        role: u.role,
      },
    };
  }
  return { ...base, user: { id: String(m.userId) } };
}

/**
 * @param {string} mealId
 * @param {string} userId
 * @param {{
 *   nutritionPartial?: Record<string, number>;
 *   title?: string;
 *   notes?: string;
 *   eatenAt?: Date;
 * }} patch
 */
async function updateMeal(mealId, userId, patch) {
  const meal = await Meal.findById(mealId);
  if (!meal) {
    throw new HttpError(404, 'Meal not found');
  }
  if (String(meal.userId) !== userId) {
    throw new HttpError(403, 'You can only edit your own meals');
  }

  if (patch.title !== undefined) {
    meal.title = patch.title;
  }
  if (patch.notes !== undefined) {
    meal.notes = patch.notes;
  }
  if (patch.eatenAt !== undefined) {
    meal.eatenAt = patch.eatenAt;
  }

  if (patch.nutritionPartial !== undefined) {
    const existing =
      meal.nutrition && typeof meal.nutrition.toObject === 'function'
        ? meal.nutrition.toObject()
        : /** @type {Record<string, number>} */ ({ ...meal.nutrition });
    meal.nutrition = mergeNutrition(existing, patch.nutritionPartial);
    meal.markModified('nutrition');
  }

  await meal.save();
  return toPublicMeal(meal);
}

/**
 * @param {Record<string, number>} existing
 * @param {Record<string, number>} partial
 */
function mergeNutrition(existing, partial) {
  const out = { ...existing };
  for (const key of Object.keys(partial)) {
    if (partial[key] !== undefined) {
      out[key] = partial[key];
    }
  }
  if (out.calories === undefined || typeof out.calories !== 'number') {
    throw new HttpError(400, 'nutrition.calories must remain set; include calories in the nutrition patch if needed');
  }
  return out;
}

/**
 * @param {string} mealId
 * @param {string} userId
 */
async function deleteMealForUser(mealId, userId) {
  const meal = await Meal.findOne({ _id: mealId, userId });
  if (!meal) {
    throw new HttpError(404, 'Meal not found');
  }
  await Meal.deleteOne({ _id: mealId });
}

/**
 * @param {number} skip
 * @param {number} limit
 * @param {object} query
 */
async function listAllMealsForAdmin(skip, limit, query) {
  const filter = buildAdminMealFilter(query);
  const sort = sortSpecFromQuery(query.sort || 'latest');
  const [items, total] = await Promise.all([
    Meal.find(filter)
      .populate('userId', 'email role')
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .exec(),
    Meal.countDocuments(filter),
  ]);

  const meals = items.map((m) => {
    const base = toPublicMealAdmin(m);
    const u = m.userId;
    if (u && typeof u === 'object' && 'email' in u && '_id' in u) {
      return {
        ...base,
        user: {
          id: String(/** @type {import('mongoose').Types.ObjectId} */ (u._id)),
          email: u.email,
          role: u.role,
        },
      };
    }
    return { ...base, user: { id: String(m.userId) } };
  });

  return { meals, total, skip, limit };
}

/**
 * @param {string} mealId
 */
async function deleteMealAsAdmin(mealId) {
  const meal = await Meal.findById(mealId);
  if (!meal) {
    throw new HttpError(404, 'Meal not found');
  }
  await Meal.deleteOne({ _id: mealId });
}

/**
 * @param {string} userId
 * @param {Date} [day]
 */
async function getUserDailyIntake(userId, day) {
  const d = day ? new Date(day) : new Date();
  const start = utcDayStart(d);
  const end = utcDayEnd(d);
  const meals = await Meal.find({
    userId,
    eatenAt: { $gte: start, $lte: end },
  })
    .sort({ eatenAt: 1 })
    .exec();
  const totalCalories = meals.reduce((s, m) => s + m.nutrition.calories, 0);
  return {
    date: start.toISOString().slice(0, 10),
    totalCalories,
    mealCount: meals.length,
    meals: meals.map((m) => toPublicMeal(m)),
  };
}

/**
 * @param {string} userId
 */
async function getUserWeeklySummary(userId) {
  const now = new Date();
  const weekStart = startOfIsoWeekUtc(now);
  const weekEnd = new Date(weekStart);
  weekEnd.setUTCDate(weekEnd.getUTCDate() + 7);
  weekEnd.setUTCMilliseconds(weekEnd.getUTCMilliseconds() - 1);

  const meals = await Meal.find({
    userId,
    eatenAt: { $gte: weekStart, $lte: weekEnd },
  }).sort({ eatenAt: 1 });

  const totalCalories = meals.reduce((s, m) => s + m.nutrition.calories, 0);

  /** @type {Record<string, { calories: number; meals: number }>} */
  const byDay = {};
  for (const m of meals) {
    const key = utcDayStart(m.eatenAt).toISOString().slice(0, 10);
    if (!byDay[key]) {
      byDay[key] = { calories: 0, meals: 0 };
    }
    byDay[key].calories += m.nutrition.calories;
    byDay[key].meals += 1;
  }

  return {
    weekStartUtc: weekStart.toISOString(),
    weekEndUtc: weekEnd.toISOString(),
    totalCalories,
    mealCount: meals.length,
    byDay,
  };
}

/**
 * @param {string} userId
 * @param {Date} from
 * @param {Date} to
 */
async function getUserNutrientBreakdown(userId, from, to) {
  const uid = new mongoose.Types.ObjectId(userId);
  const agg = await Meal.aggregate([
    { $match: { userId: uid, eatenAt: { $gte: from, $lte: to } } },
    {
      $group: {
        _id: null,
        totalCalories: { $sum: '$nutrition.calories' },
        totalProtein: { $sum: { $ifNull: ['$nutrition.protein', 0] } },
        totalCarbohydrates: { $sum: { $ifNull: ['$nutrition.carbohydrates', 0] } },
        totalFat: { $sum: { $ifNull: ['$nutrition.fat', 0] } },
        totalFiber: { $sum: { $ifNull: ['$nutrition.fiber', 0] } },
        totalSugar: { $sum: { $ifNull: ['$nutrition.sugar', 0] } },
        totalSodium: { $sum: { $ifNull: ['$nutrition.sodium', 0] } },
        mealCount: { $sum: 1 },
      },
    },
  ]);

  const row = agg[0];
  if (!row) {
    return {
      from: from.toISOString(),
      to: to.toISOString(),
      mealCount: 0,
      totals: {
        calories: 0,
        protein: 0,
        carbohydrates: 0,
        fat: 0,
        fiber: 0,
        sugar: 0,
        sodium: 0,
      },
    };
  }

  return {
    from: from.toISOString(),
    to: to.toISOString(),
    mealCount: row.mealCount,
    totals: {
      calories: row.totalCalories,
      protein: row.totalProtein,
      carbohydrates: row.totalCarbohydrates,
      fat: row.totalFat,
      fiber: row.totalFiber,
      sugar: row.totalSugar,
      sodium: row.totalSodium,
    },
  };
}

/**
 * @param {string} userId
 * @param {number} days
 */
async function getUserDietTrends(userId, days) {
  const now = new Date();
  const start = new Date(now);
  start.setUTCDate(start.getUTCDate() - days);
  const uid = new mongoose.Types.ObjectId(userId);

  const series = await Meal.aggregate([
    { $match: { userId: uid, eatenAt: { $gte: start } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$eatenAt' } },
        totalCalories: { $sum: '$nutrition.calories' },
        meals: { $sum: 1 },
      },
    },
    { $sort: { _id: 1 } },
  ]);

  return {
    days,
    series: series.map((r) => ({
      date: r._id,
      totalCalories: r.totalCalories,
      meals: r.meals,
    })),
  };
}

/**
 * @returns {Promise<object>}
 */
async function getGlobalMealStats() {
  const totalMeals = await Meal.countDocuments();
  const now = new Date();
  const start30 = new Date(now);
  start30.setUTCDate(start30.getUTCDate() - 30);
  const start7 = new Date(now);
  start7.setUTCDate(start7.getUTCDate() - 7);

  const [mealsLast7Days, mealsLast30Days, distinctUsers, avgAgg, trend] = await Promise.all([
    Meal.countDocuments({ eatenAt: { $gte: start7 } }),
    Meal.countDocuments({ eatenAt: { $gte: start30 } }),
    Meal.distinct('userId').then((ids) => ids.length),
    Meal.aggregate([
      {
        $group: {
          _id: null,
          avgCalories: { $avg: '$nutrition.calories' },
        },
      },
    ]),
    Meal.aggregate([
      { $match: { eatenAt: { $gte: start30 } } },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$eatenAt' },
          },
          meals: { $sum: 1 },
          avgCalories: { $avg: '$nutrition.calories' },
        },
      },
      { $sort: { _id: 1 } },
    ]),
  ]);

  const avgCaloriesOverall =
    avgAgg[0] && typeof avgAgg[0].avgCalories === 'number' ? avgAgg[0].avgCalories : null;

  return {
    totalMeals,
    mealsLast7Days,
    mealsLast30Days,
    usersWithMeals: distinctUsers,
    averageCaloriesPerMeal: avgCaloriesOverall,
    trendLast30DaysUtc: trend.map((row) => ({
      date: row._id,
      meals: row.meals,
      averageCalories: row.avgCalories,
    })),
  };
}

/**
 * @returns {Promise<object>}
 */
async function getSystemAnalytics() {
  const [totalUsers, mealStats, avgMealsPerUserAgg] = await Promise.all([
    User.countDocuments(),
    getGlobalMealStats(),
    Meal.aggregate([
      {
        $group: {
          _id: '$userId',
          c: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: null,
          avgMealsPerUser: { $avg: '$c' },
        },
      },
    ]),
  ]);

  const usersWithMeals = mealStats.usersWithMeals;
  const avgMealsPerUser =
    avgMealsPerUserAgg[0] && typeof avgMealsPerUserAgg[0].avgMealsPerUser === 'number'
      ? avgMealsPerUserAgg[0].avgMealsPerUser
      : null;

  return {
    users: {
      total: totalUsers,
      withMealsLogged: usersWithMeals,
      withoutMealsLogged: Math.max(0, totalUsers - usersWithMeals),
    },
    meals: {
      total: mealStats.totalMeals,
      last7Days: mealStats.mealsLast7Days,
      last30Days: mealStats.mealsLast30Days,
      averageCaloriesPerMeal: mealStats.averageCaloriesPerMeal,
    },
    insights: {
      averageMealsPerUserAmongUsersWhoLogged: avgMealsPerUser,
      suspiciousMealThresholdCalories: env.SUSPICIOUS_MEAL_CALORIES_MIN,
    },
    trendLast30DaysUtc: mealStats.trendLast30DaysUtc,
  };
}

/**
 * @returns {Promise<object>}
 */
async function getUsageReport() {
  const analytics = await getSystemAnalytics();
  const topUsers = await Meal.aggregate([
    { $group: { _id: '$userId', mealCount: { $sum: 1 } } },
    { $sort: { mealCount: -1 } },
    { $limit: 10 },
    {
      $lookup: {
        from: User.collection.collectionName,
        localField: '_id',
        foreignField: '_id',
        as: 'u',
      },
    },
    { $unwind: '$u' },
    {
      $project: {
        _id: 0,
        userId: '$_id',
        email: '$u.email',
        mealCount: 1,
      },
    },
  ]);

  const suspiciousCount = await Meal.countDocuments({
    'nutrition.calories': { $gte: env.SUSPICIOUS_MEAL_CALORIES_MIN },
  });

  return {
    generatedAt: new Date().toISOString(),
    summary: analytics,
    topUsersByMealCount: topUsers,
    qualityControl: {
      mealsAtOrAboveSuspiciousCalories: suspiciousCount,
      thresholdCalories: env.SUSPICIOUS_MEAL_CALORIES_MIN,
    },
  };
}

/**
 * Bundled admin dashboard stats. `sections` is a comma list: `system`, `meals`, `usage`.
 * @param {string | undefined} sections
 */
async function getAdminStatsBundle(sections) {
  const raw =
    sections === undefined || sections === null || String(sections).trim() === ''
      ? 'system,meals,usage'
      : String(sections);
  const parts = raw
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  const allowed = new Set(['system', 'meals', 'usage']);
  const keys = parts.filter((p) => allowed.has(p));
  const active = keys.length > 0 ? keys : ['system', 'meals', 'usage'];

  /** @type {Record<string, unknown>} */
  const out = { generatedAt: new Date().toISOString() };

  if (active.includes('system')) {
    out.system = await getSystemAnalytics();
  }
  if (active.includes('meals')) {
    out.mealsGlobal = await getGlobalMealStats();
  }
  if (active.includes('usage')) {
    out.usage = await getUsageReport();
  }

  return out;
}

module.exports = {
  createMeal,
  listMealsForUser,
  getMealForUser,
  getMealForAdmin,
  updateMeal,
  deleteMealForUser,
  listAllMealsForAdmin,
  deleteMealAsAdmin,
  getGlobalMealStats,
  getUserDailyIntake,
  getUserWeeklySummary,
  getUserNutrientBreakdown,
  getUserDietTrends,
  getSystemAnalytics,
  getUsageReport,
  getAdminStatsBundle,
};
