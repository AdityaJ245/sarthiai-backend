'use strict';

const bcrypt = require('bcryptjs');
const { User } = require('../models/User');
const { HttpError } = require('../errors/HttpError');
const { toPublicUser } = require('./authService');

/**
 * @param {{ displayName?: string; bio?: string; avatarUrl?: string }} profile
 * @returns {boolean}
 */
function isProfileEmpty(profile) {
  const displayName = (profile.displayName ?? '').trim();
  const bio = (profile.bio ?? '').trim();
  const avatarUrl = (profile.avatarUrl ?? '').trim();
  return displayName.length === 0 && bio.length === 0 && avatarUrl.length === 0;
}

/**
 * @param {string} userId
 * @param {{ displayName?: string; bio?: string; avatarUrl?: string }} patch
 */
async function updateProfile(userId, patch) {
  const user = await User.findById(userId);
  if (!user) {
    throw new HttpError(404, 'User not found');
  }
  const current = user.profile || {};
  const next = {
    displayName:
      patch.displayName !== undefined ? patch.displayName : (current.displayName ?? ''),
    bio: patch.bio !== undefined ? patch.bio : (current.bio ?? ''),
    avatarUrl:
      patch.avatarUrl !== undefined ? patch.avatarUrl : (current.avatarUrl ?? ''),
  };
  user.profile = next;
  user.markModified('profile');
  await user.save();
  return toPublicUser(user);
}

/**
 * @param {string} userId
 * @param {{ displayName: string; bio: string; avatarUrl: string }} body
 */
async function createProfile(userId, body) {
  const user = await User.findById(userId);
  if (!user) {
    throw new HttpError(404, 'User not found');
  }
  const current = user.profile || {};
  if (!isProfileEmpty(current)) {
    throw new HttpError(409, 'Profile already exists; use PATCH /users/me to update');
  }
  user.profile = {
    displayName: body.displayName,
    bio: body.bio,
    avatarUrl: body.avatarUrl,
  };
  user.markModified('profile');
  await user.save();
  return toPublicUser(user);
}

/**
 * @param {string} userId
 * @param {string} password
 */
async function deleteAccount(userId, password) {
  const user = await User.findById(userId);
  if (!user) {
    throw new HttpError(404, 'User not found');
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    throw new HttpError(401, 'Invalid password');
  }
  await User.deleteOne({ _id: userId });
}

/**
 * @param {number} skip
 * @param {number} limit
 */
async function listUsers(skip, limit) {
  const [items, total] = await Promise.all([
    User.find({}).skip(skip).limit(limit).sort({ createdAt: -1 }).exec(),
    User.countDocuments({}),
  ]);
  return {
    users: items.map((u) => toPublicUser(u)),
    total,
    skip,
    limit,
  };
}

/**
 * @param {string} targetUserId
 * @param {'user' | 'admin'} role
 */
async function setUserRole(targetUserId, role) {
  const user = await User.findByIdAndUpdate(
    targetUserId,
    { $set: { role } },
    { new: true, runValidators: true },
  );
  if (!user) {
    throw new HttpError(404, 'User not found');
  }
  return toPublicUser(user);
}

module.exports = {
  updateProfile,
  createProfile,
  deleteAccount,
  listUsers,
  setUserRole,
};
