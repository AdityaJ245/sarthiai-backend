'use strict';

const { createHash } = require('crypto');

/**
 * @param {string} token
 * @returns {string}
 */
function hashRefreshToken(token) {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}

module.exports = { hashRefreshToken };
