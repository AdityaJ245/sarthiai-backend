'use strict';

const jwt = require('jsonwebtoken');
const { env } = require('../config/env');

/** @typedef {'user' | 'admin'} UserRole */

/**
 * @param {string} userId
 * @param {UserRole} role
 * @returns {string}
 */
function signAccessToken(userId, role) {
  return jwt.sign({ typ: 'access', role }, env.JWT_ACCESS_SECRET, {
    subject: userId,
    expiresIn: env.JWT_ACCESS_EXPIRES_IN,
  });
}

/**
 * @param {string} userId
 * @returns {string}
 */
function signRefreshToken(userId) {
  return jwt.sign({ typ: 'refresh' }, env.JWT_REFRESH_SECRET, {
    subject: userId,
    expiresIn: env.JWT_REFRESH_EXPIRES_IN,
  });
}

/**
 * @param {string} token
 * @returns {import('jsonwebtoken').JwtPayload & { sub: string; typ: 'access'; role: UserRole }}
 */
function verifyAccessToken(token) {
  const decoded = jwt.verify(token, env.JWT_ACCESS_SECRET);
  if (
    typeof decoded !== 'object' ||
    decoded === null ||
    decoded.typ !== 'access' ||
    typeof decoded.sub !== 'string'
  ) {
    throw new Error('Invalid access token payload');
  }
  const role = decoded.role;
  if (role !== 'user' && role !== 'admin') {
    throw new Error('Invalid access token role');
  }
  return /** @type {import('jsonwebtoken').JwtPayload & { sub: string; typ: 'access'; role: UserRole }} */ (
    decoded
  );
}

/**
 * @param {string} token
 * @returns {import('jsonwebtoken').JwtPayload & { sub: string; typ: 'refresh' }}
 */
function verifyRefreshToken(token) {
  const decoded = jwt.verify(token, env.JWT_REFRESH_SECRET);
  if (
    typeof decoded !== 'object' ||
    decoded === null ||
    decoded.typ !== 'refresh' ||
    typeof decoded.sub !== 'string'
  ) {
    throw new Error('Invalid refresh token payload');
  }
  return /** @type {import('jsonwebtoken').JwtPayload & { sub: string; typ: 'refresh' }} */ (
    decoded
  );
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
};
