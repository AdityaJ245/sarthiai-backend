'use strict';

const { HttpError } = require('../errors/HttpError');
const { parseRegisterProfile } = require('./profile');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * @param {unknown} body
 * @returns {{ email: string; password: string }}
 */
function parseRegisterOrLogin(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const email = record.email;
  const password = record.password;
  if (typeof email !== 'string' || typeof password !== 'string') {
    throw new HttpError(400, 'email and password must be strings');
  }
  const trimmedEmail = email.trim();
  if (trimmedEmail.length === 0 || trimmedEmail.length > 255 || !EMAIL_RE.test(trimmedEmail)) {
    throw new HttpError(400, 'Invalid email');
  }
  if (password.length < 8 || password.length > 128) {
    throw new HttpError(400, 'Password must be between 8 and 128 characters');
  }
  return { email: trimmedEmail, password };
}

/**
 * Registration with optional `profile` object on the same body.
 * @param {unknown} body
 * @returns {{ email: string; password: string; profile: { displayName?: string; bio?: string; avatarUrl?: string } | undefined }}
 */
function parseRegister(body) {
  const base = parseRegisterOrLogin(body);
  const record = /** @type {Record<string, unknown>} */ (body);
  const profile = parseRegisterProfile(record.profile);
  return { email: base.email, password: base.password, profile };
}

/**
 * @param {unknown} body
 * @returns {{ refreshToken: string }}
 */
function parseRefresh(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const refreshToken = record.refreshToken;
  if (typeof refreshToken !== 'string' || refreshToken.length === 0) {
    throw new HttpError(400, 'refreshToken is required');
  }
  return { refreshToken };
}

/**
 * @param {unknown} body
 * @returns {{ refreshToken: string | undefined }}
 */
function parseLogout(body) {
  if (body === null || body === undefined) {
    return { refreshToken: undefined };
  }
  if (typeof body !== 'object') {
    throw new HttpError(400, 'Invalid JSON body');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const refreshToken = record.refreshToken;
  if (refreshToken === undefined) {
    return { refreshToken: undefined };
  }
  if (typeof refreshToken !== 'string' || refreshToken.length === 0) {
    throw new HttpError(400, 'refreshToken must be a non-empty string when provided');
  }
  return { refreshToken };
}

module.exports = {
  parseRegisterOrLogin,
  parseRegister,
  parseRefresh,
  parseLogout,
};
