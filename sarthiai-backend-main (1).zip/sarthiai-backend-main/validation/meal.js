'use strict';

const { HttpError } = require('../errors/HttpError');

/**
 * @param {unknown} value
 * @param {string} field
 * @returns {number | undefined}
 */
function optionalNonNegativeNumber(value, field) {
  if (value === undefined || value === null || value === '') {
    return undefined;
  }
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value));
  if (!Number.isFinite(n) || n < 0) {
    throw new HttpError(400, `${field} must be a non-negative number`);
  }
  return n;
}

/**
 * @param {unknown} value
 * @returns {number}
 */
function requiredCalories(value) {
  if (value === undefined || value === null || value === '') {
    throw new HttpError(400, 'nutrition.calories is required');
  }
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value));
  if (!Number.isFinite(n) || n < 0) {
    throw new HttpError(400, 'nutrition.calories must be a non-negative number');
  }
  return n;
}

/**
 * @param {Record<string, unknown>} raw
 */
function parseNutritionObject(raw) {
  const calories = requiredCalories(raw.calories);
  return {
    calories,
    protein: optionalNonNegativeNumber(raw.protein, 'nutrition.protein'),
    carbohydrates: optionalNonNegativeNumber(raw.carbohydrates, 'nutrition.carbohydrates'),
    fat: optionalNonNegativeNumber(raw.fat, 'nutrition.fat'),
    fiber: optionalNonNegativeNumber(raw.fiber, 'nutrition.fiber'),
    sugar: optionalNonNegativeNumber(raw.sugar, 'nutrition.sugar'),
    sodium: optionalNonNegativeNumber(raw.sodium, 'nutrition.sodium'),
  };
}

/**
 * Partial nutrition for PATCH (merge with existing).
 * @param {Record<string, unknown>} raw
 * @returns {Record<string, number> | undefined}
 */
function parseNutritionPartial(raw) {
  if (raw === null || typeof raw !== 'object') {
    throw new HttpError(400, 'nutrition must be an object');
  }
  /** @type {Record<string, number>} */
  const out = {};
  if (raw.calories !== undefined) {
    out.calories = requiredCalories(raw.calories);
  }
  const keys = [
    ['protein', 'nutrition.protein'],
    ['carbohydrates', 'nutrition.carbohydrates'],
    ['fat', 'nutrition.fat'],
    ['fiber', 'nutrition.fiber'],
    ['sugar', 'nutrition.sugar'],
    ['sodium', 'nutrition.sodium'],
  ];
  for (const [key, label] of keys) {
    if (raw[key] !== undefined) {
      const v = optionalNonNegativeNumber(raw[key], label);
      if (v !== undefined) {
        out[key] = v;
      }
    }
  }
  if (Object.keys(out).length === 0) {
    return undefined;
  }
  return out;
}

/**
 * @param {unknown} body
 * @returns {{ nutrition: ReturnType<typeof parseNutritionObject>; title?: string; notes?: string; eatenAt: Date }}
 */
function parseMealBody(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'Request body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);

  let nutritionRaw = record.nutrition;
  if (typeof nutritionRaw === 'string') {
    try {
      const parsed = /** @type {unknown} */ (JSON.parse(nutritionRaw));
      nutritionRaw = parsed;
    } catch {
      throw new HttpError(400, 'nutrition must be valid JSON when sent as a string');
    }
  }
  if (nutritionRaw === null || typeof nutritionRaw !== 'object') {
    throw new HttpError(400, 'nutrition object is required');
  }
  const nutrition = parseNutritionObject(/** @type {Record<string, unknown>} */ (nutritionRaw));

  const eatenAtRaw = record.eatenAt;
  if (eatenAtRaw === undefined || eatenAtRaw === null || eatenAtRaw === '') {
    throw new HttpError(400, 'eatenAt is required (ISO date string)');
  }
  const eatenAt = new Date(String(eatenAtRaw));
  if (Number.isNaN(eatenAt.getTime())) {
    throw new HttpError(400, 'eatenAt must be a valid date');
  }

  const title =
    record.title === undefined || record.title === null
      ? ''
      : typeof record.title === 'string'
        ? record.title.trim().slice(0, 200)
        : (() => {
            throw new HttpError(400, 'title must be a string');
          })();

  const notes =
    record.notes === undefined || record.notes === null
      ? ''
      : typeof record.notes === 'string'
        ? record.notes.slice(0, 2000)
        : (() => {
            throw new HttpError(400, 'notes must be a string');
          })();

  return { nutrition, title, notes, eatenAt };
}

/**
 * Partial update; merge `nutritionPartial` in the service layer.
 * @param {unknown} body
 */
function parseMealPatchBody(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'Request body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);

  /** @type {{
   *   nutritionPartial?: Record<string, number>;
   *   title?: string;
   *   notes?: string;
   *   eatenAt?: Date;
   * }} */
  const patch = {};

  if (record.nutrition !== undefined) {
    let nutritionRaw = record.nutrition;
    if (typeof nutritionRaw === 'string') {
      try {
        nutritionRaw = JSON.parse(nutritionRaw);
      } catch {
        throw new HttpError(400, 'nutrition must be valid JSON when sent as a string');
      }
    }
    if (nutritionRaw === null || typeof nutritionRaw !== 'object') {
      throw new HttpError(400, 'nutrition must be an object');
    }
    const partial = parseNutritionPartial(/** @type {Record<string, unknown>} */ (nutritionRaw));
    if (partial !== undefined) {
      patch.nutritionPartial = partial;
    }
  }

  if (record.title !== undefined) {
    if (typeof record.title !== 'string') {
      throw new HttpError(400, 'title must be a string');
    }
    patch.title = record.title.trim().slice(0, 200);
  }

  if (record.notes !== undefined) {
    if (typeof record.notes !== 'string') {
      throw new HttpError(400, 'notes must be a string');
    }
    patch.notes = record.notes.slice(0, 2000);
  }

  if (record.eatenAt !== undefined) {
    const eatenAt = new Date(String(record.eatenAt));
    if (Number.isNaN(eatenAt.getTime())) {
      throw new HttpError(400, 'eatenAt must be a valid date');
    }
    patch.eatenAt = eatenAt;
  }

  const hasAny =
    patch.nutritionPartial !== undefined ||
    patch.title !== undefined ||
    patch.notes !== undefined ||
    patch.eatenAt !== undefined;

  if (!hasAny) {
    throw new HttpError(400, 'Provide at least one of nutrition, title, notes, or eatenAt');
  }

  return patch;
}

module.exports = {
  parseMealBody,
  parseMealPatchBody,
  parseNutritionObject,
  parseNutritionPartial,
};
