'use strict';

const { HttpError } = require('../errors/HttpError');

const MAX_DISPLAY = 100;
const MAX_BIO = 500;
const MAX_AVATAR = 2048;

/**
 * @param {unknown} value
 * @param {string} field
 * @param {number} max
 * @returns {string | undefined}
 */
function optionalString(value, field, max) {
  if (value === undefined) {
    return undefined;
  }
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string`);
  }
  const trimmed = value.trim();
  if (trimmed.length > max) {
    throw new HttpError(400, `${field} is too long`);
  }
  return trimmed;
}

/**
 * Partial update: at least one field must be present.
 * @param {unknown} body
 * @returns {{ displayName?: string; bio?: string; avatarUrl?: string }}
 */
function parseProfilePatch(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const displayName = optionalString(record.displayName, 'displayName', MAX_DISPLAY);
  const bio = optionalString(record.bio, 'bio', MAX_BIO);
  const avatarUrl = optionalString(record.avatarUrl, 'avatarUrl', MAX_AVATAR);
  if (
    displayName === undefined &&
    bio === undefined &&
    avatarUrl === undefined
  ) {
    throw new HttpError(400, 'Provide at least one of displayName, bio, avatarUrl');
  }
  /** @type {{ displayName?: string; bio?: string; avatarUrl?: string }} */
  const patch = {};
  if (displayName !== undefined) patch.displayName = displayName;
  if (bio !== undefined) patch.bio = bio;
  if (avatarUrl !== undefined) patch.avatarUrl = avatarUrl;
  return patch;
}

/**
 * Create profile: all keys optional in body but at least one must be non-empty after trim.
 * @param {unknown} body
 * @returns {{ displayName: string; bio: string; avatarUrl: string }}
 */
function parseProfileCreate(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const displayName =
    record.displayName === undefined
      ? ''
      : optionalString(record.displayName, 'displayName', MAX_DISPLAY);
  const bio =
    record.bio === undefined ? '' : optionalString(record.bio, 'bio', MAX_BIO);
  const avatarUrl =
    record.avatarUrl === undefined
      ? ''
      : optionalString(record.avatarUrl, 'avatarUrl', MAX_AVATAR);
  const dn = (displayName ?? '').trim();
  const b = (bio ?? '').trim();
  const av = (avatarUrl ?? '').trim();
  if (dn.length === 0 && b.length === 0 && av.length === 0) {
    throw new HttpError(400, 'At least one profile field is required');
  }
  return {
    displayName: displayName ?? '',
    bio: bio ?? '',
    avatarUrl: avatarUrl ?? '',
  };
}

/**
 * @param {unknown} body
 * @returns {{ password: string }}
 */
function parseDeleteAccount(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const password = record.password;
  if (typeof password !== 'string' || password.length === 0) {
    throw new HttpError(400, 'password is required');
  }
  return { password };
}

/**
 * @param {unknown} body
 * @returns {{ role: 'user' | 'admin' }}
 */
function parseRoleUpdate(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);
  const role = record.role;
  if (role !== 'user' && role !== 'admin') {
    throw new HttpError(400, 'role must be "user" or "admin"');
  }
  return { role };
}

/**
 * Optional nested profile on registration.
 * @param {unknown} profile
 * @returns {{ displayName?: string; bio?: string; avatarUrl?: string } | undefined}
 */
function parseRegisterProfile(profile) {
  if (profile === undefined) {
    return undefined;
  }
  if (profile === null || typeof profile !== 'object') {
    throw new HttpError(400, 'profile must be an object');
  }
  const record = /** @type {Record<string, unknown>} */ (profile);
  const displayName =
    record.displayName === undefined
      ? undefined
      : optionalString(record.displayName, 'displayName', MAX_DISPLAY);
  const bio =
    record.bio === undefined ? undefined : optionalString(record.bio, 'bio', MAX_BIO);
  const avatarUrl =
    record.avatarUrl === undefined
      ? undefined
      : optionalString(record.avatarUrl, 'avatarUrl', MAX_AVATAR);
  if (displayName === undefined && bio === undefined && avatarUrl === undefined) {
    return undefined;
  }
  /** @type {{ displayName?: string; bio?: string; avatarUrl?: string }} */
  const out = {};
  if (displayName !== undefined) {
    out.displayName = displayName;
  }
  if (bio !== undefined) {
    out.bio = bio;
  }
  if (avatarUrl !== undefined) {
    out.avatarUrl = avatarUrl;
  }
  return out;
}

module.exports = {
  parseProfilePatch,
  parseProfileCreate,
  parseDeleteAccount,
  parseRoleUpdate,
  parseRegisterProfile,
};
