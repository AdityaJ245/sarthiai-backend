'use strict';

const { HttpError } = require('../errors/HttpError');

/**
 * @param {unknown} body
 */
function parseIntegrationUpdate(body) {
  if (body === null || typeof body !== 'object') {
    throw new HttpError(400, 'JSON body required');
  }
  const record = /** @type {Record<string, unknown>} */ (body);

  /** @type {{
   *   nutritionProvider?: string;
   *   nutritionApiBaseUrl?: string;
   *   externalWebhookUrl?: string;
   *   notes?: string;
   * }} */
  const patch = {};

  if (record.nutritionProvider !== undefined) {
    if (typeof record.nutritionProvider !== 'string') {
      throw new HttpError(400, 'nutritionProvider must be a string');
    }
    patch.nutritionProvider = record.nutritionProvider.trim().slice(0, 64);
  }
  if (record.nutritionApiBaseUrl !== undefined) {
    if (typeof record.nutritionApiBaseUrl !== 'string') {
      throw new HttpError(400, 'nutritionApiBaseUrl must be a string');
    }
    patch.nutritionApiBaseUrl = record.nutritionApiBaseUrl.trim().slice(0, 2048);
  }
  if (record.externalWebhookUrl !== undefined) {
    if (typeof record.externalWebhookUrl !== 'string') {
      throw new HttpError(400, 'externalWebhookUrl must be a string');
    }
    patch.externalWebhookUrl = record.externalWebhookUrl.trim().slice(0, 2048);
  }
  if (record.notes !== undefined) {
    if (typeof record.notes !== 'string') {
      throw new HttpError(400, 'notes must be a string');
    }
    patch.notes = record.notes.slice(0, 2000);
  }

  if (Object.keys(patch).length === 0) {
    throw new HttpError(400, 'Provide at least one field to update');
  }

  return patch;
}

module.exports = { parseIntegrationUpdate };
