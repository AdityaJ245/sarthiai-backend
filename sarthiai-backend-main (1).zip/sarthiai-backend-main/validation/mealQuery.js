'use strict';

const { HttpError } = require('../errors/HttpError');

/**
 * @param {string} str
 * @returns {string}
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * @param {import('express').Request['query']} query
 */
function parseMealListQuery(query) {
  const limitParsed = Number.parseInt(String(query.limit ?? '20'), 10);
  const skipParsed = Number.parseInt(String(query.skip ?? '0'), 10);
  const limit = Number.isFinite(limitParsed)
    ? Math.min(100, Math.max(1, limitParsed))
    : 20;
  const skip = Number.isFinite(skipParsed) && skipParsed >= 0 ? skipParsed : 0;

  const periodRaw = query.period;
  const period =
    periodRaw === 'today' || periodRaw === 'week' || periodRaw === 'month'
      ? periodRaw
      : undefined;

  const sortRaw = query.sort;
  const sort =
    sortRaw === 'calories_desc' || sortRaw === 'latest' ? sortRaw : 'latest';

  let from = query.from ? new Date(String(query.from)) : undefined;
  let to = query.to ? new Date(String(query.to)) : undefined;
  if (from !== undefined && Number.isNaN(from.getTime())) {
    throw new HttpError(400, 'from must be a valid ISO date');
  }
  if (to !== undefined && Number.isNaN(to.getTime())) {
    throw new HttpError(400, 'to must be a valid ISO date');
  }

  const q =
    query.q !== undefined && query.q !== null && String(query.q).trim() !== ''
      ? String(query.q).trim().slice(0, 200)
      : undefined;

  return { limit, skip, period, sort, from, to, q };
}

/**
 * @param {import('express').Request['query']} query
 */
function parseAdminMealListQuery(query) {
  const base = parseMealListQuery(query);
  const userId =
    query.userId !== undefined && String(query.userId).trim() !== ''
      ? String(query.userId).trim()
      : undefined;

  const suspiciousOnly = String(query.suspiciousOnly || '').toLowerCase() === 'true';

  let minCalories = undefined;
  if (query.minCalories !== undefined && query.minCalories !== '') {
    const n = Number.parseFloat(String(query.minCalories));
    if (!Number.isFinite(n) || n < 0) {
      throw new HttpError(400, 'minCalories must be a non-negative number');
    }
    minCalories = n;
  }
  let maxCalories = undefined;
  if (query.maxCalories !== undefined && query.maxCalories !== '') {
    const n = Number.parseFloat(String(query.maxCalories));
    if (!Number.isFinite(n) || n < 0) {
      throw new HttpError(400, 'maxCalories must be a non-negative number');
    }
    maxCalories = n;
  }

  return { ...base, userId, suspiciousOnly, minCalories, maxCalories };
}

/**
 * @param {import('express').Request['query']} query
 */
function parseDateQuery(query) {
  const raw = query.date;
  if (raw === undefined || raw === null || String(raw).trim() === '') {
    return undefined;
  }
  const d = new Date(String(raw));
  if (Number.isNaN(d.getTime())) {
    throw new HttpError(400, 'date must be a valid ISO date (YYYY-MM-DD)');
  }
  return d;
}

/**
 * @param {import('express').Request['query']} query
 */
function parseTrendsQuery(query) {
  const daysParsed = Number.parseInt(String(query.days ?? '30'), 10);
  const days = Number.isFinite(daysParsed) ? Math.min(365, Math.max(1, daysParsed)) : 30;
  return { days };
}

/**
 * @param {import('express').Request['query']} query
 * @param {number} [defaultDays]
 */
function parseFromToRange(query, defaultDays) {
  const days = defaultDays === undefined ? 30 : defaultDays;
  const now = new Date();
  if (query.from && query.to) {
    const from = new Date(String(query.from));
    const to = new Date(String(query.to));
    if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
      throw new HttpError(400, 'from and to must be valid ISO dates');
    }
    return { from, to };
  }
  const from = new Date(now);
  from.setUTCDate(from.getUTCDate() - days);
  return { from, to: now };
}

module.exports = {
  escapeRegex,
  parseMealListQuery,
  parseAdminMealListQuery,
  parseDateQuery,
  parseTrendsQuery,
  parseFromToRange,
};
