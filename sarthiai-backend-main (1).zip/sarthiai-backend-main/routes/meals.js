'use strict';

const express = require('express');
const { HttpError } = require('../errors/HttpError');
const { requireAuth } = require('../middleware/requireAuth');
const mealService = require('../services/mealService');
const { parseMealBody, parseMealPatchBody } = require('../validation/meal');
const { parseMealListQuery } = require('../validation/mealQuery');

const router = express.Router();

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const input = parseMealBody(req.body);
    const meal = await mealService.createMeal(userId, input);
    res.status(201).json({ meal });
  } catch (err) {
    next(err);
  }
});

router.get('/', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const query = parseMealListQuery(req.query);
    const { limit, skip, ...rest } = query;
    const result = await mealService.listMealsForUser(userId, skip, limit, rest);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/:mealId', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const meal = await mealService.getMealForUser(req.params.mealId, userId);
    res.json({ meal });
  } catch (err) {
    next(err);
  }
});

router.patch('/:mealId', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const patch = parseMealPatchBody(req.body);
    const meal = await mealService.updateMeal(req.params.mealId, userId, patch);
    res.json({ meal });
  } catch (err) {
    next(err);
  }
});

router.delete('/:mealId', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    await mealService.deleteMealForUser(req.params.mealId, userId);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = { mealsRouter: router };
