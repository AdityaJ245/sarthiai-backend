'use strict';

const express = require('express');
const { HttpError } = require('../errors/HttpError');
const { requireAuth } = require('../middleware/requireAuth');
const mealService = require('../services/mealService');
const {
  parseDateQuery,
  parseTrendsQuery,
  parseFromToRange,
} = require('../validation/mealQuery');

const router = express.Router();

/**
 * Single response with own analytics (optional query: date, days, from, to — same as sub-routes).
 */
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const day = parseDateQuery(req.query);
    const { days } = parseTrendsQuery(req.query);
    const { from, to } = parseFromToRange(req.query, 30);
    const [daily, weekly, nutrients, trends] = await Promise.all([
      mealService.getUserDailyIntake(userId, day),
      mealService.getUserWeeklySummary(userId),
      mealService.getUserNutrientBreakdown(userId, from, to),
      mealService.getUserDietTrends(userId, days),
    ]);
    res.json({ daily, weekly, nutrients, trends });
  } catch (err) {
    next(err);
  }
});

router.get('/daily', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const day = parseDateQuery(req.query);
    const result = await mealService.getUserDailyIntake(userId, day);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/weekly', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const result = await mealService.getUserWeeklySummary(userId);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/nutrients', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const { from, to } = parseFromToRange(req.query, 30);
    const result = await mealService.getUserNutrientBreakdown(userId, from, to);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/trends', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const { days } = parseTrendsQuery(req.query);
    const result = await mealService.getUserDietTrends(userId, days);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

module.exports = { summaryRouter: router };
