'use strict';

const express = require('express');
const { HttpError } = require('../errors/HttpError');
const { requireAuth } = require('../middleware/requireAuth');
const { requireRole } = require('../middleware/requireRole');
const userService = require('../services/userService');
const mealService = require('../services/mealService');
const systemHealthService = require('../services/systemHealthService');
const integrationService = require('../services/integrationService');
const errorLog = require('../lib/errorLog');
const { parseRoleUpdate } = require('../validation/profile');
const { parseAdminMealListQuery } = require('../validation/mealQuery');
const { parseIntegrationUpdate } = require('../validation/integrations');

const router = express.Router();

router.get(
  '/system/health',
  requireAuth,
  requireRole('admin'),
  (_req, res, next) => {
    try {
      res.json(systemHealthService.getSystemHealth());
    } catch (err) {
      next(err);
    }
  },
);

router.get(
  '/system/errors',
  requireAuth,
  requireRole('admin'),
  (req, res, next) => {
    try {
      const limitParsed = Number.parseInt(String(req.query.limit ?? '50'), 10);
      const limit = Number.isFinite(limitParsed)
        ? Math.min(100, Math.max(1, limitParsed))
        : 50;
      const errors = errorLog.getRecent(limit);
      res.json({ count: errors.length, errors });
    } catch (err) {
      next(err);
    }
  },
);

/**
 * Consolidated statistics: `?sections=system,meals,usage` (optional; default all).
 */
router.get(
  '/stats',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const sections =
        req.query.sections === undefined ? undefined : String(req.query.sections);
      const bundle = await mealService.getAdminStatsBundle(sections);
      res.json(bundle);
    } catch (err) {
      next(err);
    }
  },
);

router.get(
  '/integrations',
  requireAuth,
  requireRole('admin'),
  async (_req, res, next) => {
    try {
      const settings = await integrationService.getAdminIntegrationSettings();
      res.json({ settings });
    } catch (err) {
      next(err);
    }
  },
);

router.put(
  '/integrations',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const patch = parseIntegrationUpdate(req.body);
      const settings = await integrationService.updateAdminIntegrationSettings(patch);
      res.json({ settings });
    } catch (err) {
      next(err);
    }
  },
);

/**
 * @param {import('express').Request['query']} query
 */
function parsePagination(query) {
  const limitRaw = query.limit;
  const skipRaw = query.skip;
  const limitParsed = Number.parseInt(String(limitRaw ?? '20'), 10);
  const skipParsed = Number.parseInt(String(skipRaw ?? '0'), 10);
  const limit = Number.isFinite(limitParsed)
    ? Math.min(100, Math.max(1, limitParsed))
    : 20;
  const skip = Number.isFinite(skipParsed) && skipParsed >= 0 ? skipParsed : 0;
  return { limit, skip };
}

router.get(
  '/users',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const { limit, skip } = parsePagination(req.query);
      const result = await userService.listUsers(skip, limit);
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
);

router.patch(
  '/users/:userId/role',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const targetUserId = req.params.userId;
      if (!targetUserId) {
        next(new HttpError(400, 'userId is required'));
        return;
      }
      const { role } = parseRoleUpdate(req.body);
      const user = await userService.setUserRole(targetUserId, role);
      res.json({ user });
    } catch (err) {
      next(err);
    }
  },
);

router.get(
  '/meals',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const query = parseAdminMealListQuery(req.query);
      const { limit, skip, ...rest } = query;
      const result = await mealService.listAllMealsForAdmin(skip, limit, rest);
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
);

router.get(
  '/meals/:mealId',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const mealId = req.params.mealId;
      if (!mealId) {
        next(new HttpError(400, 'mealId is required'));
        return;
      }
      const meal = await mealService.getMealForAdmin(mealId);
      res.json({ meal });
    } catch (err) {
      next(err);
    }
  },
);

router.delete(
  '/meals/:mealId',
  requireAuth,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const mealId = req.params.mealId;
      if (!mealId) {
        next(new HttpError(400, 'mealId is required'));
        return;
      }
      await mealService.deleteMealAsAdmin(mealId);
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);

module.exports = { adminRouter: router };
