'use strict';

const express = require('express');
const { HttpError } = require('../errors/HttpError');
const { requireAuth } = require('../middleware/requireAuth');
const authService = require('../services/authService');
const userService = require('../services/userService');
const {
  parseProfilePatch,
  parseProfileCreate,
  parseDeleteAccount,
} = require('../validation/profile');

const router = express.Router();

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const user = await authService.getUserById(userId);
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

router.patch('/me', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const patch = parseProfilePatch(req.body);
    const user = await userService.updateProfile(userId, patch);
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

router.post('/profile', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const body = parseProfileCreate(req.body);
    const user = await userService.createProfile(userId, body);
    res.status(201).json({ user });
  } catch (err) {
    next(err);
  }
});

router.delete('/me', requireAuth, async (req, res, next) => {
  try {
    const userId = req.userId;
    if (userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const { password } = parseDeleteAccount(req.body);
    await userService.deleteAccount(userId, password);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = { usersRouter: router };
