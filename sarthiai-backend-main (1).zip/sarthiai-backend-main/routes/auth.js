'use strict';

const express = require('express');
const authService = require('../services/authService');
const { parseRegister, parseRegisterOrLogin, parseRefresh, parseLogout } = require('../validation/auth');

const router = express.Router();

router.post('/register', async (req, res, next) => {
  try {
    const { email, password, profile } = parseRegister(req.body);
    const result = await authService.registerUser(email, password, profile);
    res.status(201).json({
      user: result.user,
      accessToken: result.tokens.accessToken,
      refreshToken: result.tokens.refreshToken,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = parseRegisterOrLogin(req.body);
    const result = await authService.loginUser(email, password);
    res.json({
      user: result.user,
      accessToken: result.tokens.accessToken,
      refreshToken: result.tokens.refreshToken,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/refresh', async (req, res, next) => {
  try {
    const { refreshToken } = parseRefresh(req.body);
    const tokens = await authService.refreshSession(refreshToken);
    res.json({
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', async (req, res, next) => {
  try {
    const { refreshToken } = parseLogout(req.body);
    await authService.logoutUser(refreshToken);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = { authRouter: router };
