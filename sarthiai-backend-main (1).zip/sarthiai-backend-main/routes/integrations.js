'use strict';

const express = require('express');
const { HttpError } = require('../errors/HttpError');
const { requireAuth } = require('../middleware/requireAuth');
const integrationService = require('../services/integrationService');

const router = express.Router();

/**
 * Client-safe integration flags for building UX against external nutrition/webhook flows.
 */
router.get('/', requireAuth, async (req, res, next) => {
  try {
    if (req.userId === undefined) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const integration = await integrationService.getPublicIntegrationInfo();
    res.json({ integration });
  } catch (err) {
    next(err);
  }
});

module.exports = { integrationsRouter: router };
