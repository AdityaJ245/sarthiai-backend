'use strict';

const express = require('express');
const multer = require('multer');
const { requireAuth } = require('../middleware/requireAuth');
const { HttpError } = require('../errors/HttpError');
const { recognizeFoodViaMicroservice } = require('../services/foodAiService');
const { getMacroSummaryFromGemini } = require('../services/geminiService');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = typeof file.mimetype === 'string' && file.mimetype.startsWith('image/');
    if (!ok) {
      cb(new HttpError(400, 'Only image uploads are allowed'));
      return;
    }
    cb(null, true);
  },
});

router.post('/recognize', requireAuth, upload.single('photo'), async (req, res, next) => {
  try {
    if (!req.userId) {
      next(new HttpError(500, 'Authentication context was not set'));
      return;
    }
    const file = req.file;
    if (!file || !file.buffer) {
      next(new HttpError(400, 'Missing uploaded photo. Send multipart/form-data with field "photo"'));
      return;
    }

    const result = await recognizeFoodViaMicroservice({
      imageBuffer: file.buffer,
      mimeType: file.mimetype || 'image/jpeg',
      filename: file.originalname || 'photo.jpg',
    });

    const summary = await getMacroSummaryFromGemini(result.recognized.name);
    res.json({ ...result, summary });
  } catch (err) {
    next(err);
  }
});

module.exports = { foodRouter: router };

