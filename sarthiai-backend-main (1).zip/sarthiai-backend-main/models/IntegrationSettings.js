'use strict';

const mongoose = require('mongoose');

/**
 * Singleton-style document: at most one row; use findOne + upsert in the service.
 */
const integrationSettingsSchema = new mongoose.Schema(
  {
    nutritionProvider: {
      type: String,
      trim: true,
      default: 'manual',
      maxlength: 64,
    },
    nutritionApiBaseUrl: {
      type: String,
      trim: true,
      default: '',
      maxlength: 2048,
    },
    externalWebhookUrl: {
      type: String,
      trim: true,
      default: '',
      maxlength: 2048,
    },
    notes: { type: String, default: '', maxlength: 2000 },
  },
  { timestamps: true },
);

const IntegrationSettings = mongoose.model('IntegrationSettings', integrationSettingsSchema);

module.exports = { IntegrationSettings };
