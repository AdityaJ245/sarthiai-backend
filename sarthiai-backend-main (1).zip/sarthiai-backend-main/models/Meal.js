'use strict';

const mongoose = require('mongoose');

const nutritionSchema = new mongoose.Schema(
  {
    calories: { type: Number, required: true, min: 0 },
    protein: { type: Number, min: 0 },
    carbohydrates: { type: Number, min: 0 },
    fat: { type: Number, min: 0 },
    fiber: { type: Number, min: 0 },
    sugar: { type: Number, min: 0 },
    sodium: { type: Number, min: 0 },
  },
  { _id: false },
);

const mealSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    title: { type: String, trim: true, default: '', maxlength: 200 },
    notes: { type: String, default: '', maxlength: 2000 },
    eatenAt: { type: Date, required: true, index: true },
    nutrition: { type: nutritionSchema, required: true },
  },
  { timestamps: true },
);

mealSchema.index({ userId: 1, eatenAt: -1 });

const Meal = mongoose.model('Meal', mealSchema);

module.exports = { Meal };
