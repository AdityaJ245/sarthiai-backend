'use strict';

const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema(
  {
    displayName: { type: String, trim: true, default: '', maxlength: 100 },
    bio: { type: String, default: '', maxlength: 500 },
    avatarUrl: { type: String, default: '', trim: true, maxlength: 2048 },
  },
  { _id: false },
);

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      maxlength: 255,
    },
    passwordHash: { type: String, required: true },
    refreshTokenHash: { type: String, default: null },
    role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user',
    },
    profile: { type: profileSchema, default: () => ({}) },
  },
  { timestamps: true },
);

const User = mongoose.model('User', userSchema);

module.exports = { User };
