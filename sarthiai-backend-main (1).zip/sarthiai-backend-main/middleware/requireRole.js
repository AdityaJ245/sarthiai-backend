'use strict';

const { HttpError } = require('../errors/HttpError');

/**
 * @param {'user' | 'admin'} requiredRole
 * @returns {import('express').RequestHandler}
 */
function requireRole(requiredRole) {
  return (req, res, next) => {
    const userRole = req.userRole;
    if (userRole !== requiredRole) {
      next(new HttpError(403, 'Forbidden'));
      return;
    }
    next();
  };
}

/** Shorthand for `requireRole('admin')` — full system access & moderation. */
const requireAdmin = requireRole('admin');

module.exports = { requireRole, requireAdmin };
