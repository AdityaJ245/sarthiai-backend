'use strict';

const { HttpError } = require('../errors/HttpError');
const { verifyAccessToken } = require('../utils/jwt');

const BEARER_PREFIX = 'Bearer ';

/**
 * Validates Bearer JWT and attaches identity to the request.
 * - `req.userId` — subject from the access token (Mongo user id).
 * - `req.userRole` — `'user'` or `'admin'` from the token (refresh to pick up role changes).
 *
 * **Access model:** route handlers must scope data to `req.userId` for non-admin callers.
 * Use `requireRole('admin')` after this for elevated routes.
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function requireAuth(req, res, next) {
  const headerValue = req.headers.authorization;
  if (headerValue === undefined || !headerValue.startsWith(BEARER_PREFIX)) {
    next(new HttpError(401, 'Missing or invalid Authorization header'));
    return;
  }
  const token = headerValue.slice(BEARER_PREFIX.length).trim();
  if (token.length === 0) {
    next(new HttpError(401, 'Missing or invalid Authorization header'));
    return;
  }
  try {
    const payload = verifyAccessToken(token);
    req.userId = payload.sub;
    req.userRole = payload.role;
    next();
  } catch {
    next(new HttpError(401, 'Invalid or expired access token'));
  }
}

module.exports = { requireAuth };
