'use strict';

const { HttpError } = require('../errors/HttpError');
const errorLog = require('../lib/errorLog');

/**
 * @param {unknown} err
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} _next
 */
function errorHandler(err, req, res, _next) {
  const method = req.method;
  const path = req.originalUrl || req.url;

  if (err instanceof HttpError) {
    if (err.statusCode >= 500) {
      errorLog.record({
        recordedAt: new Date().toISOString(),
        type: 'server',
        statusCode: err.statusCode,
        message: err.message,
        stack: err.stack,
        method,
        path,
      });
    }
    const body = { error: err.message };
    if (err.details !== undefined) {
      body.details = err.details;
    }
    res.status(err.statusCode).json(body);
    return;
  }
  if (err && typeof err === 'object' && 'name' in err && err.name === 'ValidationError') {
    res.status(400).json({ error: 'Validation failed', details: String(err) });
    return;
  }

  errorLog.record({
    recordedAt: new Date().toISOString(),
    type: 'unhandled',
    message: err instanceof Error ? err.message : String(err),
    stack: err instanceof Error ? err.stack : undefined,
    method,
    path,
  });
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
}

module.exports = { errorHandler };
