'use strict';

require('dotenv').config();

/**
 * @returns {void}
 */
function requireEnv(name) {
  const value = process.env[name];
  if (value === undefined || value.trim() === '') {
    throw new Error(`Missing required environment variable: ${name}`);
  }
}

requireEnv('MONGODB_URI');
requireEnv('JWT_ACCESS_SECRET');
requireEnv('JWT_REFRESH_SECRET');

if (process.env.JWT_ACCESS_SECRET.length < 32) {
  throw new Error('JWT_ACCESS_SECRET must be at least 32 characters');
}
if (process.env.JWT_REFRESH_SECRET.length < 32) {
  throw new Error('JWT_REFRESH_SECRET must be at least 32 characters');
}

/**
 * @typedef {object} Env
 * @property {string} NODE_ENV
 * @property {number} PORT
 * @property {string} MONGODB_URI
 * @property {string} JWT_ACCESS_SECRET
 * @property {string} JWT_REFRESH_SECRET
 * @property {string} JWT_ACCESS_EXPIRES_IN
 * @property {string} JWT_REFRESH_EXPIRES_IN
 * @property {string | undefined} CORS_ORIGIN
 * @property {number} SUSPICIOUS_MEAL_CALORIES_MIN
 * @property {boolean} TRUST_PROXY
 * @property {string} FOOD_AI_URL
 * @property {string | undefined} GEMINI_API_KEY
 * @property {string | undefined} GEMINI_MODEL
 */

const SUSPICIOUS_RAW = Number.parseInt(process.env.SUSPICIOUS_MEAL_CALORIES_MIN || '5000', 10);

/** @type {Env} */
const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number.parseInt(process.env.PORT || '3000', 10),
  MONGODB_URI: process.env.MONGODB_URI,
  JWT_ACCESS_SECRET: process.env.JWT_ACCESS_SECRET,
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET,
  JWT_ACCESS_EXPIRES_IN: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  CORS_ORIGIN: process.env.CORS_ORIGIN,
  SUSPICIOUS_MEAL_CALORIES_MIN: Number.isFinite(SUSPICIOUS_RAW) && SUSPICIOUS_RAW > 0 ? SUSPICIOUS_RAW : 5000,
  TRUST_PROXY: process.env.TRUST_PROXY === 'true' || process.env.TRUST_PROXY === '1',
  FOOD_AI_URL: (process.env.FOOD_AI_URL || 'http://localhost:8001').replace(/\/$/, ''),
  GEMINI_API_KEY: process.env.GEMINI_API_KEY,
  GEMINI_MODEL: process.env.GEMINI_MODEL,
};

module.exports = { env };
